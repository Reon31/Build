﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class atarihantei : MonoBehaviour
{

    GameObject Ball;
 
    // Start is called before the first frame update
    void Start()
    {
        Ball = GameObject.Find("Ball");
    }

    // Update is called once per frame
    void Update()
    {
        
        int x=1;
        int y=1;

        

        Vector2 ob = this.transform.position;
        Vector2 ball = Ball.transform.position;
        if (ob == ball)
        {
            ball = new Vector2(x++, y++); ;
            Debug.Log("atari");
        }
    }
}
