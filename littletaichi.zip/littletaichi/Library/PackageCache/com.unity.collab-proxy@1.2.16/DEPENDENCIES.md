<?xml version="1.0"?>
<package xmlns="http://schemas.microsoft.com/packaging/2013/05/nuspec.xsd">
    <metadata>
    <id>Unity.CollabProxy.Dependencies</id>
    <version>1.1.0-experimental</version>
    <authors>Rohit Garg</authors>
    <description>Dependencies for the CollabProxy package</description>
    </metadata>
</package>
